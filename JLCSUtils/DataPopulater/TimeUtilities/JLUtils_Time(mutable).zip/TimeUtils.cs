﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JohnLambe.Util.Time
{ 
    /// <summary>
    /// Time-related utilities.
    /// </summary>
    public static class TimeUtils
    {
        #region Constants
        // Time-related constants (to use for readability):

        public const int HoursPerDay = 24;
        public const int MinutesPerHour = 60;
        public const int SecondsPerMinute = 60;
        public const int DaysPerWeek = 7;

        #endregion

        #region TimeOfDay

        /// <summary>
        /// Returns the time-of-day part of the given timespan.
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static TimeSpan? TimeOfDay(this TimeSpan? value)
        {
            if (value == null)
                return null;
            else
                return new TimeSpan(value.Value.Ticks % TimeSpan.TicksPerDay);
        }

        public static TimeSpan TimeOfDay(this TimeSpan value)
        {
            return new TimeSpan(value.Ticks % TimeSpan.TicksPerDay);
        }

        #endregion

        #region IsDateOnly / IsTimeOfDay
        // These could be extension methods, but might seem like clutter in the list in the IDE.

        // Could add overloads for nullable types, but what should they do on null? :
        // return true (because it is valid as a nullable date or time part) or throw an exception.

        public static bool IsDateOnly(DateTime datetime)
        {
            return datetime.TimeOfDay == TimeSpan.Zero;
        }

        /// <summary>
        /// True if the given TimeSpan is a valid time of day (positive and less than a day).
        /// </summary>
        /// <param name="timeSpan"></param>
        /// <returns></returns>
        public static bool IsTimeOfDay(TimeSpan timeSpan)
        {
            return timeSpan >= TimeSpan.Zero && timeSpan.Days == 0;
        }

        /// <summary>
        /// True if the given date-time value has only a time part (the Date part is DateTime.MinValue).
        /// </summary>
        /// <param name="time"></param>
        /// <returns></returns>
        public static bool IsTimeOfDay(DateTime time)
        {
            return time.Date == DateTime.MinValue;
        }

        #endregion

        #region FormDate
        // Combine a DateTime date part and TimeSpan time part to form a DateTime, with validation.

        /// <summary>
        /// Form a DateTime from a date and time part.
        /// </summary>
        /// <param name="datePart">The date part. This must have a time of 00:00.</param>
        /// <param name="timePart">The time part. This must be a time of day: positive and less than a day.</param>
        /// <exception cref="ArgumentException"/>
        /// <returns></returns>
        public static DateTime FormDate(DateTime datePart, TimeSpan timePart)
        {
            if (!IsDateOnly(datePart))
                throw new ArgumentException("Date contains time part");
            if (!IsTimeOfDay(timePart))
                throw new ArgumentException("Time is not a valid time of day");
            return datePart + timePart;
        }

        /// <summary>
        /// Convert a timespan representing a time of day to a DateTime.
        /// (The Date part will be DateTime.MinValue).
        /// </summary>
        /// <param name="timePart">The time part. This must be a time of day: positive and less than a day.</param>
        /// <exception cref="ArgumentException"/>
        /// <returns></returns>
        //| This could be an extension method of TimeSpan, but that might encourage the use of DateTime for holding a time of day
        //| (TimeSpan is more appropriate).
        public static DateTime FormDate(TimeSpan timePart)
        {
            if (!IsTimeOfDay(timePart))
                throw new ArgumentException("Time is not a valid time of day");
            return DateTime.MinValue + timePart;
        }

        #endregion
    }
}
