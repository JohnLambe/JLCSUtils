﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JohnLambe.Util.Time
{
    /// <summary>
    /// A date with no time part.
    /// </summary>
    public struct Date : IEquatable<Object>, IComparable
    {
        #region Constructors

        /// <summary>
        /// Initializes to a specified number of ticks.
        /// </summary>
        /// <param name="ticks">
        /// A date and time expressed in the number of 100-nanosecond intervals that have
        ///     elapsed since January 1, 0001 at 00:00:00.000 in the Gregorian calendar (as
        ///     for the DateTime constructor).
        /// Must be a multiple of TimeSpan.TicksPerDay - no time-of-day part.</param>
        public Date(long ticks)
        {
            if (ticks % TimeSpan.TicksPerDay != 0)            // must not have a time part
                throw new ArgumentException("Invalid `ticks` value for Date (" + ticks + ")");
            _value = new DateTime(ticks);
        }

        public Date(int year, int month, int day)
        {
            _value = new DateTime(year, month, day);
        }

        /// <summary>
        /// Initializes from a DateTime? value. There must be no time part in this value.
        /// </summary>
        /// <param name="value"></param>
        public Date(DateTime? value = null)
        {
            if (value.HasValue && !TimeUtils.IsDateOnly(value.Value))
                throw new ArgumentException("Can't cast DateTime to Date because it has a time part");
            _value = value;
        }

        #endregion

        /// <summary>
        /// The underlying value.
        /// </summary>
        private DateTime? _value;

        /// <summary>
        /// The Date value as a <see cref="DateTime"/>.
        /// </summary>
        public DateTime Value
        {
            get { return _value.Value;  }
            set { _value = value.Date; }
        }

        /// <summary>
        /// Allows assigning the value, silently dropping the time part.
        /// Otherwise, this is the same as <see cref="Value"/>.
        /// </summary>
        public DateTime ValueTruncated
        {
            get
            {
                return _value.Value;
                // same as _value.Value.Date because it is checked on assignment.
            }
            set { _value = value.Date; }
        }

        public bool HasValue
        {
            get { return _value.HasValue; }
        }

        #region Methods

        public Date AddDays(int delta)
        {
            return new Date(_value.Value.AddDays(delta));
        }

        #endregion

        #region Properties
        // Properties for parts of the date.
        // These throw an exception if the value is null.
        // They could alternatively have returned int? and returned null
        // when the DateTime value is null, but if someone is using these,
        // they're probably assuming that it has a value.

        public int Year
        {
            get { return _value.Value.Year; }
        }
        public int Month
        {
            get { return _value.Value.Month; }
        }
        public int Day
        {
            get { return _value.Value.Day; }
        }
        public DayOfWeek DayOfWeek
        {
            get { return _value.Value.DayOfWeek; }
        }
        public int DayOfYear
        {
            get { return _value.Value.DayOfYear; }
        }

        public long Ticks
        {
            get { return _value.Value.Ticks; }
        }

        #endregion

        #region Casting

        public static implicit operator DateTime(Date value)
        {
            return value.Value;
        }

        /// <summary>
        /// 
        /// Requires an explicit cast because it can lose information (the time part).
        /// </summary>
        /// <param name="value"></param>
        public static explicit operator Date(DateTime value)
        {
            return new Date(value);
        }

        #endregion

        #region + and - operators

        public static Date operator +(Date date, TimeSpan delta)
        {
            return new Date(date.Value + delta);
        }

        public static Date operator -(Date date, TimeSpan delta)
        {
            return new Date(date.Value - delta);
        }

        #endregion

        #region Comparison operators

        public static bool operator ==(Date a, Date b)
        {
            return a._value == b._value;
        }
        public static bool operator !=(Date a, Date b)
        {
            return a._value != b._value;
        }

        public static bool operator <(Date a, Date b)
        {
            return a._value < b._value;
        }
        public static bool operator >(Date a, Date b)
        {
            return a._value > b._value;
        }
        public static bool operator >=(Date a, Date b)
        {
            return a._value >= b._value;
        }
        public static bool operator <=(Date a, Date b)
        {
            return a._value >= b._value;
        }

        #endregion

        #region Equals and GetHashCode

        public override bool Equals(object other)
        {
            if (other == null)
                return _value == null;         // equal if both are null

            else if (other is Date)
                return _value == ((Date)other)._value;

            else if (other is DateTime)
                return _value.HasValue && _value.Value == (DateTime)other;
            else if (other is DateTime?)
                return _value == (DateTime?)other;

            else
                return base.Equals(other);
        }

        public override int GetHashCode()
        {
            return _value.GetHashCode();
        }

        public int CompareTo(object obj)
        {
            throw new NotImplementedException();
        }

        #endregion
    }

}
