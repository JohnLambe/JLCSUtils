﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JohnLambe.Util.Time
{
    /// <summary>
    /// A nullable time-of-day value - effectively a timespan in the range 0 (inclusive) to 1 day (exclusive).
    /// <para>For consistency with <see cref="TimeSpan"/>, this uses <see cref="int"/>
    /// for parts of the time, and handles negative or out-of-range values similarly.
    /// </para>
    /// </summary>
    public struct Time : IEquatable<object>
    {
        #region Constructors

        /// <summary>
        /// Construct from a number of ticks.
        /// </summary>
        /// <param name="ticks">Number of ticks, must not be negative, nor more than 24 hours.</param>
        public Time(long ticks)
        {
            if (ticks >= TimeSpan.TicksPerDay || ticks < 0)
                throw new ArgumentException("Invalid `ticks` value for Time (" + ticks + ")");
            _value = new TimeSpan(ticks);
        }

        public Time(int hours, int minutes, int seconds = 0, int milliseconds = 0)
        {
//            if (hours >= TimeUtils.HoursPerDay || hours < 0)
//                throw new ArgumentException("Invalid value for Time (" + hours + " hours)");
            TimeSpan value = new TimeSpan(hours, minutes, seconds, milliseconds);
            if(!TimeUtils.IsTimeOfDay(value))
                throw new ArgumentException("Invalid value for Time of day (" + value + " )");
            _value = value;
        }

        public Time(TimeSpan? value = null)
        {
            if (value.HasValue && !TimeUtils.IsTimeOfDay(value.Value))
                throw new ArgumentException("Invalid value for Time of day (" + value + " )");
            _value = value;
        }

        #endregion

        private TimeSpan? _value;

        public TimeSpan Value
        {
            get { return _value.Value; }
            set { _value = value.TimeOfDay(); }
        }

        public bool HasValue
        {
            get { return _value.HasValue; }
        }

        #region Properties
        // Properties for parts of the date.
        // These throw an exception if the value is null.
        // They could alternatively have returned int? and returned null
        // when the DateTime value is null, but if someone is using these,
        // they're probably assuming that it has a value.

        public int Hours
        {
            get { return _value.Value.Hours; }
        }
        public int Minutes
        {
            get { return _value.Value.Minutes; }
        }
        public int Seconds
        {
            get { return _value.Value.Seconds; }
        }
        public int Milliseconds
        {
            get { return _value.Value.Milliseconds; }
        }

        /// <summary>
        /// The value as a fraction of a day (in the range 0 (inclusive) to 1 (exclusive)).
        /// </summary>
        public double TotalDays
        {
            get { return _value.Value.TotalDays; }
        }
        public double TotalHours
        {
            get { return _value.Value.TotalHours; }
        }
        public double TotalMinutes
        {
            get { return _value.Value.TotalMinutes; }
        }
        public double TotalSeconds
        {
            get { return _value.Value.TotalSeconds; }
        }
        public double TotalMilliseconds
        {
            get { return _value.Value.TotalMilliseconds; }
        }

        public long Ticks
        {
            get { return _value.Value.Ticks; }
        }

        #endregion

        #region Casting

        public static implicit operator TimeSpan(Time value)
        {
            return value.Value;
        }

        public static explicit operator Time(TimeSpan value)
        {
            if (value.TotalDays >= 1)
                throw new InvalidCastException("Can't cast DateTime to Time because it has a date part");
            else if(value < TimeSpan.Zero)
                throw new InvalidCastException("Can't cast DateTime to Time because it is negative");
            return new Time(value);
        }

        #endregion

        #region + and - operators

        public static Time operator +(Time time, TimeSpan delta)
        {
            return new Time(time.Value + delta);
        }

        public static Time operator -(Time time, TimeSpan delta)
        {
            return new Time(time.Value - delta);
        }

        #endregion

        #region Comparison operators

        public static bool operator ==(Time a, Time b)
        {
            return a._value == b._value;
        }
        public static bool operator !=(Time a, Time b)
        {
            return a._value != b._value;
        }

        public static bool operator <(Time a, Time b)
        {
            return a._value < b._value;
        }
        public static bool operator >(Time a, Time b)
        {
            return a._value > b._value;
        }
        public static bool operator >=(Time a, Time b)
        {
            return a._value >= b._value;
        }
        public static bool operator <=(Time a, Time b)
        {
            return a._value >= b._value;
        }

        #endregion

        #region Equals and GetHashCode

        public override bool Equals(object other)
        {
            if (other == null)
                return _value == null;         // equal if both are null

            else if (other is Time)
                return _value == ((Time)other)._value;

            else if (other is TimeSpan?)
                return _value == (TimeSpan?)other;
            else if (other is TimeSpan)
                return _value.HasValue && _value.Value == (TimeSpan)other;

            else if (other is DateTime)
                return _value == ((DateTime)other).TimeOfDay
                    && ((DateTime?)other).Value.Date == DateTime.MinValue;
            else if (other is DateTime?)
                return (!_value.HasValue && !((DateTime?)other).HasValue)
                    || (_value.HasValue && ((DateTime?)other).HasValue
                    && _value == ((DateTime?)other).Value.TimeOfDay
                    && ((DateTime?)other).Value.Date == DateTime.MinValue);

            else
                return base.Equals(other);
        }

        public override int GetHashCode()
        {
            return _value.GetHashCode();
        }

        #endregion

    }
}
